#!c:\apps\geonode-2.4.x\geonode-2.4.x\scripts\python.exe
import arcrest.admin

arcrest.admin.cmdline.createcacheschema()
