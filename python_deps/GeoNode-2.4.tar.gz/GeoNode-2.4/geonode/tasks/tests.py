from django.test import TestCase


class TasksTests(TestCase):
    pass
