# -*- coding: utf-8 -*-

###############################################
# Geosite master local_settings
###############################################

# path for static and uploaded files
# SERVE_PATH = ''

# share a database
"""
DATABASES = {
    'default' : {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': '',
        'USER' : '',
        'PASSWORD' : '',
        'HOST' : 'localhost',
        'PORT' : '5432',
    }
    # vector datastore for uploads
    # 'datastore' : {
    #    'ENGINE': 'django.contrib.gis.db.backends.postgis',
    #    'NAME': '',
    #    'USER' : '',
    #    'PASSWORD' : '',
    #    'HOST' : '',
    #    'PORT' : '',
    # }
}
"""

# internal url to GeoServer
GEOSERVER_URL = 'http://localhost:8080/geoserver/'
