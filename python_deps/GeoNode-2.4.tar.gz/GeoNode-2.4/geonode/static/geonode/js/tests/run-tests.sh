java -jar libs/js.jar -opt -1 libs/bootstrap.js SpecRunner.html
