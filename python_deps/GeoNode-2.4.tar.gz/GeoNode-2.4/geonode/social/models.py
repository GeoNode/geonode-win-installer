import geonode.social.signals  # noqa
