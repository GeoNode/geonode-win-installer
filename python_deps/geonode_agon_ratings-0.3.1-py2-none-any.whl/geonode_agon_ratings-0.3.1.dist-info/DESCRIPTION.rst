agon-ratings
============

Provides user ratings of objects.


Documentation
-------------

Documentation can be found online at http://agon-ratings.readthedocs.org/.



