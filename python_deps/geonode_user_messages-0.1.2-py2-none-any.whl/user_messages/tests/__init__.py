from user_messages.tests.test_messages import (TestMessages, TestMessageViews,
    TestTemplateTags)
