#!python
import arcrest.admin

arcrest.admin.cmdline.createcacheschema()
