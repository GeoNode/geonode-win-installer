# backward compatibility
# Print deprecation warning in next release
from paver.path import *

