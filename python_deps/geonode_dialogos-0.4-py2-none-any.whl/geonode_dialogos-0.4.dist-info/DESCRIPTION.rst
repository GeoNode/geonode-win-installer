Dialogos 
========

Dialogos is a comments app for Django.


