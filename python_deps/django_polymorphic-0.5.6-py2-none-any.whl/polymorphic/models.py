# -*- coding: utf-8 -*-
"""
IMPORTANT:

The models.py module is not used anymore.
Please use the following import method in your apps:

    from polymorphic import PolymorphicModel, ...

"""
